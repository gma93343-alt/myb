# 智能聊天子系统 - 后台管理控制器
import tornado.web
import json
from app.controllers.base import BaseHandler
from app.models.chat import GroupRepository, FileRepository, ChatServerRepository
from app.models.digital_employee import DigitalEmployeeRepository, ToolRepository
from app.models.user import UserRepository

class ChatAdminPageHandler(BaseHandler):
    """聊天管理后台页面"""
    @tornado.web.authenticated
    def get(self, page_type):
        if page_type == "groups":
            self.render("chat_admin/groups.html", title="群管理")
        elif page_type == "files":
            self.render("chat_admin/files.html", title="文件管理")
        elif page_type == "servers":
            self.render("chat_admin/servers.html", title="服务器管理")
        elif page_type == "employees":
            self.render("chat_admin/employees.html", title="数字员工管理")
        elif page_type == "tools":
            self.render("chat_admin/tools.html", title="工具管理")
        else:
            self.set_status(404)
            self.write("页面不存在")


class ChatGroupAdminApiHandler(BaseHandler):
    """群管理API"""
    @tornado.web.authenticated
    def get(self):
        """获取群列表"""
        action = self.get_argument("action", "list")
        
        if action == "list":
            page = int(self.get_argument("page", 1))
            limit = int(self.get_argument("limit", 10))
            
            with __import__('app.models.db', fromlist=['get_connection']).get_connection() as conn:
                offset = (page - 1) * limit
                cursor = conn.execute(
                    """SELECT g.*, u.username as owner_name, u.nickname as owner_nickname,
                        (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count
                    FROM chat_groups g
                    JOIN users u ON g.owner_id = u.id
                    ORDER BY g.create_at DESC
                    LIMIT ? OFFSET ?""",
                    (limit, offset)
                )
                groups = [dict(row) for row in cursor.fetchall()]
                
                cursor = conn.execute("SELECT COUNT(*) as count FROM chat_groups")
                total = cursor.fetchone()['count']
                
                self.write({"code": 0, "msg": "", "count": total, "data": groups})
                
        elif action == "members":
            group_id = int(self.get_argument("group_id", 0))
            members = GroupRepository.get_group_members(group_id)
            self.write({"code": 0, "data": members})
            
        elif action == "detail":
            group_id = int(self.get_argument("group_id", 0))
            group = GroupRepository.get_group(group_id)
            if group:
                self.write({"code": 0, "data": group})
            else:
                self.write({"code": 1, "msg": "群不存在"})
    
    @tornado.web.authenticated
    def post(self):
        """群管理操作"""
        action = self.get_argument("action", "")
        
        if action == "dissolve":
            # 解散群聊
            group_id = int(self.get_argument("group_id", 0))
            if GroupRepository.ban_group(group_id, False):
                # 实际上是解散，将status设为0
                with __import__('app.models.db', fromlist=['get_connection']).get_connection() as conn:
                    conn.execute("UPDATE chat_groups SET status = 0 WHERE id = ?", (group_id,))
                    conn.commit()
                self.write({"code": 0, "msg": "群聊已解散"})
            else:
                self.write({"code": 1, "msg": "操作失败"})
                
        elif action == "ban":
            # 封禁群聊
            group_id = int(self.get_argument("group_id", 0))
            if GroupRepository.ban_group(group_id, True):
                self.write({"code": 0, "msg": "群聊已封禁"})
            else:
                self.write({"code": 1, "msg": "操作失败"})
                
        elif action == "unban":
            # 解封群聊
            group_id = int(self.get_argument("group_id", 0))
            if GroupRepository.ban_group(group_id, False):
                self.write({"code": 0, "msg": "群聊已解封"})
            else:
                self.write({"code": 1, "msg": "操作失败"})
                
        elif action == "announcement":
            # 发布群公告
            group_id = int(self.get_argument("group_id", 0))
            announcement = self.get_argument("announcement", "").strip()
            
            with __import__('app.models.db', fromlist=['get_connection']).get_connection() as conn:
                conn.execute(
                    "UPDATE chat_groups SET announcement = ? WHERE id = ?",
                    (announcement, group_id)
                )
                conn.commit()
                
                # 发送系统消息到群
                conn.execute(
                    """INSERT INTO messages (sender_id, group_id, msg_type, content)
                    VALUES (?, ?, ?, ?)""",
                    (0, group_id, 5, f"【系统公告】{announcement}")
                )
                conn.commit()
                
            self.write({"code": 0, "msg": "公告已发布"})
            
        elif action == "remove_member":
            # 移除群成员
            group_id = int(self.get_argument("group_id", 0))
            user_id = int(self.get_argument("user_id", 0))
            
            with __import__('app.models.db', fromlist=['get_connection']).get_connection() as conn:
                conn.execute(
                    "DELETE FROM group_members WHERE group_id = ? AND user_id = ?",
                    (group_id, user_id)
                )
                conn.commit()
            
            self.write({"code": 0, "msg": "成员已移除"})


class ChatFileAdminApiHandler(BaseHandler):
    """文件管理API"""
    @tornado.web.authenticated
    def get(self):
        """获取文件列表"""
        page = int(self.get_argument("page", 1))
        limit = int(self.get_argument("limit", 10))
        
        files, total = FileRepository.get_files_list(page, limit)
        self.write({"code": 0, "msg": "", "count": total, "data": files})
    
    @tornado.web.authenticated
    def post(self):
        """文件管理操作"""
        action = self.get_argument("action", "")
        
        if action == "delete":
            file_id = int(self.get_argument("file_id", 0))
            result = FileRepository.delete_file(file_id)
            
            if isinstance(result, str):
                # 需要删除物理文件
                import os
                file_path = os.path.join(
                    os.path.dirname(__file__), '..', 'static', 'uploads', 
                    os.path.basename(result)
                )
                if os.path.exists(file_path):
                    os.remove(file_path)
                self.write({"code": 0, "msg": "文件已删除"})
            elif result is True:
                self.write({"code": 0, "msg": "文件引用已减少"})
            else:
                self.write({"code": 1, "msg": "删除失败"})
                
        elif action == "clean":
            # 清理重复文件
            with __import__('app.models.db', fromlist=['get_connection']).get_connection() as conn:
                cursor = conn.execute(
                    """SELECT file_hash, COUNT(*) as count 
                    FROM files 
                    GROUP BY file_hash 
                    HAVING count > 1"""
                )
                duplicates = cursor.fetchall()
                
                cleaned = 0
                for dup in duplicates:
                    cursor = conn.execute(
                        "SELECT id FROM files WHERE file_hash = ? ORDER BY id ASC",
                        (dup['file_hash'],)
                    )
                    ids = [row['id'] for row in cursor.fetchall()]
                    # 保留第一个，更新其他为引用
                    for file_id in ids[1:]:
                        conn.execute(
                            "UPDATE files SET ref_count = 0 WHERE id = ?",
                            (file_id,)
                        )
                        cleaned += 1
                
                conn.commit()
                self.write({"code": 0, "msg": f"清理完成，合并了 {cleaned} 个重复引用"})


class ChatServerAdminApiHandler(BaseHandler):
    """服务器管理API"""
    @tornado.web.authenticated
    def get(self):
        """获取服务器列表"""
        servers = ChatServerRepository.get_servers()
        self.write({"code": 0, "data": servers})
    
    @tornado.web.authenticated
    def post(self):
        """服务器管理操作"""
        action = self.get_argument("action", "")
        
        if action == "add":
            name = self.get_argument("name", "").strip()
            host = self.get_argument("host", "").strip()
            port = int(self.get_argument("port", 10086))
            ws_port = self.get_argument("ws_port", None)
            if ws_port:
                ws_port = int(ws_port)
            priority = int(self.get_argument("priority", 0))
            
            if not all([name, host]):
                self.write({"code": 1, "msg": "名称和主机不能为空"})
                return
            
            server_id = ChatServerRepository.add_server(name, host, port, ws_port, priority)
            if server_id:
                self.write({"code": 0, "msg": "服务器添加成功", "data": {"id": server_id}})
            else:
                self.write({"code": 1, "msg": "添加失败"})
                
        elif action == "edit":
            server_id = int(self.get_argument("server_id", 0))
            kwargs = {}
            
            for field in ['name', 'host', 'port', 'ws_port', 'priority', 'status']:
                value = self.get_argument(field, None)
                if value is not None:
                    if field in ['port', 'ws_port', 'priority', 'status']:
                        value = int(value)
                    kwargs[field] = value
            
            if ChatServerRepository.update_server(server_id, **kwargs):
                self.write({"code": 0, "msg": "服务器更新成功"})
            else:
                self.write({"code": 1, "msg": "更新失败"})
                
        elif action == "delete":
            server_id = int(self.get_argument("server_id", 0))
            if ChatServerRepository.delete_server(server_id):
                self.write({"code": 0, "msg": "服务器已删除"})
            else:
                self.write({"code": 1, "msg": "删除失败"})
                
        elif action == "set_default":
            server_id = int(self.get_argument("server_id", 0))
            with __import__('app.models.db', fromlist=['get_connection']).get_connection() as conn:
                conn.execute("UPDATE chat_servers SET is_default = 0")
                conn.execute(
                    "UPDATE chat_servers SET is_default = 1 WHERE id = ?",
                    (server_id,)
                )
                conn.commit()
            self.write({"code": 0, "msg": "默认服务器已设置"})


class DigitalEmployeeAdminApiHandler(BaseHandler):
    """数字员工管理API"""
    @tornado.web.authenticated
    def get(self):
        """获取数字员工列表"""
        action = self.get_argument("action", "list")
        
        if action == "list":
            employees = DigitalEmployeeRepository.get_all_employees()
            self.write({"code": 0, "data": employees})
            
        elif action == "detail":
            employee_id = int(self.get_argument("employee_id", 0))
            employee = DigitalEmployeeRepository.get_employee_by_id(employee_id)
            if employee:
                # 获取绑定的工具
                tools = DigitalEmployeeRepository.get_employee_tools(employee_id)
                employee['tools'] = tools
                self.write({"code": 0, "data": employee})
            else:
                self.write({"code": 1, "msg": "数字员工不存在"})
    
    @tornado.web.authenticated
    def post(self):
        """数字员工管理操作"""
        action = self.get_argument("action", "")
        
        if action == "add":
            name = self.get_argument("name", "").strip()
            display_name = self.get_argument("display_name", "").strip()
            description = self.get_argument("description", "").strip()
            employee_type = self.get_argument("employee_type", "custom")
            prompt_template = self.get_argument("prompt_template", "").strip()
            model_id = self.get_argument("model_id", None)
            if model_id:
                model_id = int(model_id)
            
            if not all([name, display_name]):
                self.write({"code": 1, "msg": "名称和显示名不能为空"})
                return
            
            employee_id = DigitalEmployeeRepository.create_employee(
                name, display_name, description, employee_type,
                prompt_template, model_id
            )
            if employee_id:
                self.write({"code": 0, "msg": "数字员工创建成功", "data": {"id": employee_id}})
            else:
                self.write({"code": 1, "msg": "创建失败"})
                
        elif action == "edit":
            employee_id = int(self.get_argument("employee_id", 0))
            kwargs = {}
            
            for field in ['display_name', 'description', 'prompt_template', 'model_id', 'is_active']:
                value = self.get_argument(field, None)
                if value is not None:
                    if field == 'model_id':
                        value = int(value) if value else None
                    elif field == 'is_active':
                        value = int(value)
                    kwargs[field] = value
            
            if DigitalEmployeeRepository.update_employee(employee_id, **kwargs):
                self.write({"code": 0, "msg": "数字员工更新成功"})
            else:
                self.write({"code": 1, "msg": "更新失败"})
                
        elif action == "delete":
            employee_id = int(self.get_argument("employee_id", 0))
            if DigitalEmployeeRepository.delete_employee(employee_id):
                self.write({"code": 0, "msg": "数字员工已删除"})
            else:
                self.write({"code": 1, "msg": "删除失败"})
                
        elif action == "bind_tool":
            employee_id = int(self.get_argument("employee_id", 0))
            tool_id = int(self.get_argument("tool_id", 0))
            config_str = self.get_argument("config", "{}")
            
            try:
                config = json.loads(config_str)
            except:
                config = {}
            
            if DigitalEmployeeRepository.bind_tool(employee_id, tool_id, config):
                self.write({"code": 0, "msg": "工具绑定成功"})
            else:
                self.write({"code": 1, "msg": "绑定失败"})
                
        elif action == "unbind_tool":
            employee_id = int(self.get_argument("employee_id", 0))
            tool_id = int(self.get_argument("tool_id", 0))
            
            if DigitalEmployeeRepository.unbind_tool(employee_id, tool_id):
                self.write({"code": 0, "msg": "工具解绑成功"})
            else:
                self.write({"code": 1, "msg": "解绑失败"})


class ToolAdminApiHandler(BaseHandler):
    """工具管理API"""
    @tornado.web.authenticated
    def get(self):
        """获取工具列表"""
        tools = ToolRepository.get_all_tools()
        self.write({"code": 0, "data": tools})
    
    @tornado.web.authenticated
    def post(self):
        """工具管理操作"""
        action = self.get_argument("action", "")
        
        if action == "add":
            name = self.get_argument("name", "").strip()
            display_name = self.get_argument("display_name", "").strip()
            description = self.get_argument("description", "").strip()
            tool_type = self.get_argument("tool_type", "api")
            config_str = self.get_argument("config", "{}")
            
            try:
                config = json.loads(config_str)
            except:
                config = {}
            
            if not all([name, display_name]):
                self.write({"code": 1, "msg": "名称和显示名不能为空"})
                return
            
            tool_id = ToolRepository.create_tool(name, display_name, description, tool_type, config)
            if tool_id:
                self.write({"code": 0, "msg": "工具创建成功", "data": {"id": tool_id}})
            else:
                self.write({"code": 1, "msg": "创建失败"})
                
        elif action == "edit":
            tool_id = int(self.get_argument("tool_id", 0))
            kwargs = {}
            
            for field in ['display_name', 'description', 'tool_type', 'config', 'is_active']:
                value = self.get_argument(field, None)
                if value is not None:
                    if field == 'config':
                        try:
                            value = json.loads(value)
                        except:
                            value = {}
                    elif field == 'is_active':
                        value = int(value)
                    kwargs[field] = value
            
            if ToolRepository.update_tool(tool_id, **kwargs):
                self.write({"code": 0, "msg": "工具更新成功"})
            else:
                self.write({"code": 1, "msg": "更新失败"})
                
        elif action == "delete":
            tool_id = int(self.get_argument("tool_id", 0))
            if ToolRepository.delete_tool(tool_id):
                self.write({"code": 0, "msg": "工具已删除"})
            else:
                self.write({"code": 1, "msg": "删除失败"})
